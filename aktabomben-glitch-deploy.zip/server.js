const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

// Serve static files
app.use(express.static('public'));

// Game rooms and waiting players
const gameRooms = new Map();
let waitingPlayers = [];
let onlinePlayers = new Map();

// Default canvas dimensions
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;

// Socket.IO connection handling
io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);

    // Handle player login
    socket.on('login', (username) => {
        // Check if username is valid
        if (!username || username.trim() === '') {
            socket.emit('loginError', 'Please enter a valid username');
            return;
        }

        // Check if username is already taken
        const usernameTaken = Array.from(onlinePlayers.values()).some(player => 
            player.username.toLowerCase() === username.toLowerCase()
        );

        if (usernameTaken) {
            socket.emit('loginError', 'Username already taken');
            return;
        }

        // Add player to online players
        onlinePlayers.set(socket.id, {
            id: socket.id,
            username: username,
            inGame: false
        });

        // Send login success
        socket.emit('loginSuccess', { username });
        
        // Broadcast updated player count
        io.emit('updateOnlineCount', onlinePlayers.size);
    });

    // Handle player joining matchmaking
    socket.on('joinMatchmaking', () => {
        const player = onlinePlayers.get(socket.id);
        if (!player) return;

        console.log('Player joining matchmaking:', player.username);
        
        // Mark player as in matchmaking
        player.inGame = true;
        
        // Add player to waiting list
        waitingPlayers.push(socket.id);
        socket.emit('waitingForMatch');

        // If we have enough players, create a match
        if (waitingPlayers.length >= 2) {
            const player1Id = waitingPlayers.shift();
            const player2Id = waitingPlayers.shift();
            
            const player1 = onlinePlayers.get(player1Id);
            const player2 = onlinePlayers.get(player2Id);
            
            if (!player1 || !player2) return;
            
            const roomId = Math.random().toString(36).substring(2, 8);

            // Create new room
            const room = {
                id: roomId,
                players: new Map(),
                gameState: {
                    isRunning: false,
                    gameMap: [],
                    bombs: [],
                    explosions: [],
                    powerUps: []
                }
            };

            // Add players to room
            room.players.set(player1Id, {
                id: player1Id,
                username: player1.username,
                x: 40,
                y: 40,
                color: '#3498db'
            });

            room.players.set(player2Id, {
                id: player2Id,
                username: player2.username,
                x: CANVAS_WIDTH - 80,
                y: CANVAS_HEIGHT - 80,
                color: '#e74c3c'
            });

            gameRooms.set(roomId, room);

            // Join both players to the room
            io.sockets.sockets.get(player1Id).join(roomId);
            io.sockets.sockets.get(player2Id).join(roomId);

            // Start the game
            room.gameState.isRunning = true;
            io.to(roomId).emit('gameStart', {
                roomId: roomId,
                players: Array.from(room.players.values())
            });
        }
    });

    // Handle player canceling matchmaking
    socket.on('cancelMatchmaking', () => {
        const player = onlinePlayers.get(socket.id);
        if (!player) return;

        // Remove from waiting list
        const index = waitingPlayers.indexOf(socket.id);
        if (index !== -1) {
            waitingPlayers.splice(index, 1);
            player.inGame = false;
        }
    });

    // Handle player movement
    socket.on('playerMove', (data) => {
        const room = findPlayerRoom(socket.id);
        if (!room) return;

        const player = room.players.get(socket.id);
        if (!player) return;

        player.x = data.x;
        player.y = data.y;

        socket.to(room.id).emit('playerMoved', {
            playerId: socket.id,
            x: data.x,
            y: data.y
        });
    });

    // Handle bomb placement
    socket.on('placeBomb', (data) => {
        const room = findPlayerRoom(socket.id);
        if (!room) return;

        const bomb = {
            id: Date.now(),
            x: data.x,
            y: data.y,
            playerId: socket.id
        };
        room.gameState.bombs.push(bomb);

        io.to(room.id).emit('bombPlaced', bomb);
    });

    // Handle explosion
    socket.on('explosion', (data) => {
        const room = findPlayerRoom(socket.id);
        if (!room) return;

        io.to(room.id).emit('explosion', data);
    });

    // Handle player death
    socket.on('playerDied', () => {
        const room = findPlayerRoom(socket.id);
        if (!room) return;

        // Notify other player of victory
        socket.to(room.id).emit('playerWon');
    });

    // Handle disconnection
    socket.on('disconnect', () => {
        // Remove from online players
        onlinePlayers.delete(socket.id);
        
        // Broadcast updated player count
        io.emit('updateOnlineCount', onlinePlayers.size);
        
        // Remove from waiting list if disconnected while matchmaking
        const waitingIndex = waitingPlayers.indexOf(socket.id);
        if (waitingIndex !== -1) {
            waitingPlayers.splice(waitingIndex, 1);
            return;
        }

        // Handle disconnection from game room
        const room = findPlayerRoom(socket.id);
        if (!room) return;

        room.players.delete(socket.id);
        socket.to(room.id).emit('playerLeft', socket.id);

        if (room.players.size === 0) {
            gameRooms.delete(room.id);
        }
    });

    // Handle play again request
    socket.on('playAgain', () => {
        const player = onlinePlayers.get(socket.id);
        if (!player) return;
        
        player.inGame = false;
        socket.emit('returnToLobby');
    });
});

// Helper function to find a player's room
function findPlayerRoom(playerId) {
    for (const [roomId, room] of gameRooms) {
        if (room.players.has(playerId)) {
            return room;
        }
    }
    return null;
}

// Start server
const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
}); 