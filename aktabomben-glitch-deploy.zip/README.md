# Aktabomben Multiplayer

A real-time multiplayer bomb game where players compete to be the last one standing.

## Features

- Real-time multiplayer gameplay
- Power-ups system (Range, Speed, Bombs)
- Destructible walls
- Mobile-friendly controls
- Game stats tracking

## How to Deploy on Glitch

1. Create a new project on [Glitch](https://glitch.com/)
2. Import this repository or upload these files
3. The app will automatically start running

## Development

- The game uses Express.js for the server
- Socket.IO for real-time communication
- HTML5 Canvas for rendering

## Controls

- Arrow keys or WASD to move
- Spacebar to place bombs
- Mobile controls available on touch devices

## Credits

Created by Samy Mouhamedsiraj 