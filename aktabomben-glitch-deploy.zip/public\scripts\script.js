// Socket.io connection
const socket = io();

// Game constants
const GRID_SIZE = 40;
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const ROWS = CANVAS_HEIGHT / GRID_SIZE;
const COLS = CANVAS_WIDTH / GRID_SIZE;

// Game state
const gameState = {
    isRunning: false,
    isPaused: false,
    gameStartTime: 0,
    elapsedTime: 0,
    lastTimestamp: 0,
    player: null,
    opponent: null,
    bombs: new Map(),
    explosions: [],
    powerUps: [],
    walls: new Set(),
    indestructibleWalls: new Set(),
    score: 0,
    playerStats: {
        bombCount: 1,
        maxBombs: 1,
        explosionRange: 2,
        speed: 5,
        speedMultiplier: 1
    }
};

// UI Elements
const screens = {
    start: document.getElementById('start-menu'),
    login: document.getElementById('login-screen'),
    howTo: document.getElementById('how-to-play-screen'),
    settings: document.getElementById('settings-screen'),
    lobby: document.getElementById('lobby-screen'),
    game: document.getElementById('game-screen'),
    pause: document.getElementById('pause-menu'),
    gameOver: document.getElementById('game-over-screen')
};

// Canvas setup
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = CANVAS_WIDTH;
canvas.height = CANVAS_HEIGHT;

// Input state
const keys = {
    ArrowUp: false,
    ArrowDown: false,
    ArrowLeft: false,
    ArrowRight: false,
    w: false,
    s: false,
    a: false,
    d: false,
    ' ': false
};

// Sound settings
let soundEnabled = true;
let musicEnabled = true;
let vibrationEnabled = true;

// Event Listeners
document.getElementById('play-online-btn').addEventListener('click', () => showScreen('login'));
document.getElementById('how-to-play-btn').addEventListener('click', () => showScreen('howTo'));
document.getElementById('settings-btn').addEventListener('click', () => showScreen('settings'));

document.getElementById('login-back-btn').addEventListener('click', () => showScreen('start'));
document.getElementById('how-to-play-back-btn').addEventListener('click', () => showScreen('start'));
document.getElementById('settings-back-btn').addEventListener('click', () => showScreen('start'));
document.getElementById('lobby-back-btn').addEventListener('click', () => {
    socket.emit('cancelMatchmaking');
    showScreen('start');
});

document.getElementById('play-button').addEventListener('click', handleLogin);
document.getElementById('cancel-button').addEventListener('click', () => {
    socket.emit('cancelMatchmaking');
    showScreen('start');
});

document.getElementById('pause-button').addEventListener('click', togglePause);
document.getElementById('resume-btn').addEventListener('click', togglePause);
document.getElementById('quit-btn').addEventListener('click', quitGame);
document.getElementById('play-again').addEventListener('click', playAgain);
document.getElementById('back-to-lobby').addEventListener('click', () => showScreen('start'));

// Settings toggles
document.getElementById('sound-toggle').addEventListener('change', (e) => {
    soundEnabled = e.target.checked;
    localStorage.setItem('soundEnabled', soundEnabled);
});

document.getElementById('music-toggle').addEventListener('change', (e) => {
    musicEnabled = e.target.checked;
    localStorage.setItem('musicEnabled', musicEnabled);
});

document.getElementById('vibration-toggle').addEventListener('change', (e) => {
    vibrationEnabled = e.target.checked;
    localStorage.setItem('vibrationEnabled', vibrationEnabled);
});

// Load settings from localStorage
function loadSettings() {
    soundEnabled = localStorage.getItem('soundEnabled') !== 'false';
    musicEnabled = localStorage.getItem('musicEnabled') !== 'false';
    vibrationEnabled = localStorage.getItem('vibrationEnabled') !== 'false';
    
    document.getElementById('sound-toggle').checked = soundEnabled;
    document.getElementById('music-toggle').checked = musicEnabled;
    document.getElementById('vibration-toggle').checked = vibrationEnabled;
}

// Screen management
function showScreen(screenId) {
    Object.values(screens).forEach(screen => {
        if (screen) screen.style.display = 'none';
    });
    if (screens[screenId]) {
        screens[screenId].style.display = 'block';
    }
}

// Login handling
function handleLogin() {
    const username = document.getElementById('username-input').value.trim();
    if (username) {
        socket.emit('login', username);
    } else {
        document.getElementById('login-error').textContent = 'Please enter a username';
    }
}

// Game initialization
function initGame(data) {
    gameState.isRunning = true;
    gameState.gameStartTime = Date.now();
    gameState.lastTimestamp = gameState.gameStartTime;
    gameState.player = data.players.find(p => p.id === socket.id);
    gameState.opponent = data.players.find(p => p.id !== socket.id);
    
    // Reset player stats
    gameState.playerStats = {
        bombCount: 1,
        maxBombs: 1,
        explosionRange: 2,
        speed: 5,
        speedMultiplier: 1
    };
    
    // Update UI
    document.getElementById('player-name').textContent = gameState.player.username;
    document.getElementById('opponent-name').textContent = gameState.opponent.username;
    updateStats();
    
    // Start game loop
    requestAnimationFrame(gameLoop);
}

// Game loop
function gameLoop(timestamp) {
    if (!gameState.isRunning || gameState.isPaused) return;
    
    const deltaTime = timestamp - gameState.lastTimestamp;
    gameState.lastTimestamp = timestamp;
    gameState.elapsedTime = Math.floor((timestamp - gameState.gameStartTime) / 1000);
    
    update(deltaTime);
    render();
    updateUI();
    
    requestAnimationFrame(gameLoop);
}

// Update game state
function update(deltaTime) {
    if (!gameState.player) return;
    
    // Player movement
    const moveSpeed = gameState.playerStats.speed * gameState.playerStats.speedMultiplier * (deltaTime / 1000);
    let dx = 0;
    let dy = 0;
    
    if (keys.ArrowUp || keys.w) dy -= moveSpeed;
    if (keys.ArrowDown || keys.s) dy += moveSpeed;
    if (keys.ArrowLeft || keys.a) dx -= moveSpeed;
    if (keys.ArrowRight || keys.d) dx += moveSpeed;
    
    // Normalize diagonal movement
    if (dx !== 0 && dy !== 0) {
        dx *= Math.SQRT1_2;
        dy *= Math.SQRT1_2;
    }
    
    // Check collision and update position
    const newX = gameState.player.x + dx;
    const newY = gameState.player.y + dy;
    
    if (!checkCollision(newX, newY)) {
        gameState.player.x = newX;
        gameState.player.y = newY;
        socket.emit('playerMove', { x: newX, y: newY });
    }
    
    // Update bombs
    for (const [bombId, bomb] of gameState.bombs) {
        if (Date.now() >= bomb.detonationTime) {
            detonateBomb(bombId);
        }
    }
    
    // Update explosions
    gameState.explosions = gameState.explosions.filter(explosion => {
        explosion.duration -= deltaTime;
        return explosion.duration > 0;
    });
}

// Render game
function render() {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw grid
    ctx.strokeStyle = '#ddd';
    ctx.lineWidth = 1;
    for (let i = 0; i <= ROWS; i++) {
        ctx.beginPath();
        ctx.moveTo(0, i * GRID_SIZE);
        ctx.lineTo(canvas.width, i * GRID_SIZE);
        ctx.stroke();
    }
    for (let i = 0; i <= COLS; i++) {
        ctx.beginPath();
        ctx.moveTo(i * GRID_SIZE, 0);
        ctx.lineTo(i * GRID_SIZE, canvas.height);
        ctx.stroke();
    }
    
    // Draw walls
    ctx.fillStyle = '#8B4513';
    for (const wall of gameState.walls) {
        ctx.fillRect(wall.x * GRID_SIZE, wall.y * GRID_SIZE, GRID_SIZE, GRID_SIZE);
    }
    
    ctx.fillStyle = '#666';
    for (const wall of gameState.indestructibleWalls) {
        ctx.fillRect(wall.x * GRID_SIZE, wall.y * GRID_SIZE, GRID_SIZE, GRID_SIZE);
    }
    
    // Draw power-ups
    for (const powerUp of gameState.powerUps) {
        drawPowerUp(powerUp);
    }
    
    // Draw bombs
    for (const bomb of gameState.bombs.values()) {
        drawBomb(bomb);
    }
    
    // Draw explosions
    for (const explosion of gameState.explosions) {
        drawExplosion(explosion);
    }
    
    // Draw players
    if (gameState.player) {
        drawPlayer(gameState.player, '#3498db');
    }
    if (gameState.opponent) {
        drawPlayer(gameState.opponent, '#e74c3c');
    }
}

// Draw functions
function drawPlayer(player, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(player.x, player.y, GRID_SIZE / 3, 0, Math.PI * 2);
    ctx.fill();
}

function drawBomb(bomb) {
    const timeLeft = (bomb.detonationTime - Date.now()) / 1000;
    const pulseScale = 1 + Math.sin(Date.now() / 200) * 0.1;
    
    ctx.fillStyle = '#333';
    ctx.beginPath();
    ctx.arc(bomb.x, bomb.y, (GRID_SIZE / 3) * pulseScale, 0, Math.PI * 2);
    ctx.fill();
    
    // Draw fuse
    ctx.strokeStyle = '#f39c12';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(bomb.x, bomb.y - GRID_SIZE / 3);
    ctx.quadraticCurveTo(
        bomb.x + GRID_SIZE / 4,
        bomb.y - GRID_SIZE / 2,
        bomb.x + GRID_SIZE / 3,
        bomb.y - GRID_SIZE / 4
    );
    ctx.stroke();
    
    // Draw timer
    ctx.fillStyle = '#fff';
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(timeLeft.toFixed(1), bomb.x, bomb.y + 4);
}

function drawExplosion(explosion) {
    const alpha = explosion.duration / 1000;
    ctx.fillStyle = `rgba(255, 69, 0, ${alpha})`;
    
    for (const cell of explosion.cells) {
        ctx.fillRect(
            cell.x * GRID_SIZE,
            cell.y * GRID_SIZE,
            GRID_SIZE,
            GRID_SIZE
        );
    }
}

function drawPowerUp(powerUp) {
    const pulseScale = 1 + Math.sin(Date.now() / 300) * 0.1;
    const radius = (GRID_SIZE / 3) * pulseScale;
    
    ctx.fillStyle = powerUp.color;
    ctx.beginPath();
    ctx.arc(
        powerUp.x * GRID_SIZE + GRID_SIZE / 2,
        powerUp.y * GRID_SIZE + GRID_SIZE / 2,
        radius,
        0,
        Math.PI * 2
    );
    ctx.fill();
    
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(
        powerUp.symbol,
        powerUp.x * GRID_SIZE + GRID_SIZE / 2,
        powerUp.y * GRID_SIZE + GRID_SIZE / 2
    );
}

// Game mechanics
function placeBomb() {
    if (gameState.bombs.size >= gameState.playerStats.maxBombs) return;
    
    const gridX = Math.floor(gameState.player.x / GRID_SIZE);
    const gridY = Math.floor(gameState.player.y / GRID_SIZE);
    const bombX = gridX * GRID_SIZE + GRID_SIZE / 2;
    const bombY = gridY * GRID_SIZE + GRID_SIZE / 2;
    
    const bomb = {
        id: Date.now(),
        x: bombX,
        y: bombY,
        gridX: gridX,
        gridY: gridY,
        playerId: socket.id,
        detonationTime: Date.now() + 2000
    };
    
    gameState.bombs.set(bomb.id, bomb);
    socket.emit('placeBomb', bomb);
}

function detonateBomb(bombId) {
    const bomb = gameState.bombs.get(bombId);
    if (!bomb) return;
    
    const explosionCells = calculateExplosion(bomb);
    const explosion = {
        cells: explosionCells,
        duration: 1000
    };
    
    gameState.explosions.push(explosion);
    gameState.bombs.delete(bombId);
    
    socket.emit('explosion', {
        bombId: bombId,
        cells: explosionCells
    });
    
    // Check for player death
    if (isPlayerInExplosion(gameState.player, explosionCells)) {
        handlePlayerDeath();
    }
}

function calculateExplosion(bomb) {
    const cells = [{x: bomb.gridX, y: bomb.gridY}];
    const range = gameState.playerStats.explosionRange;
    const directions = [[0, -1], [1, 0], [0, 1], [-1, 0]];
    
    for (const [dx, dy] of directions) {
        for (let i = 1; i <= range; i++) {
            const x = bomb.gridX + (dx * i);
            const y = bomb.gridY + (dy * i);
            
            if (x < 0 || x >= COLS || y < 0 || y >= ROWS) break;
            
            if (gameState.indestructibleWalls.has(`${x},${y}`)) break;
            
            cells.push({x, y});
            
            if (gameState.walls.has(`${x},${y}`)) {
                gameState.walls.delete(`${x},${y}`);
                if (Math.random() < 0.3) {
                    spawnPowerUp(x, y);
                }
                break;
            }
        }
    }
    
    return cells;
}

function spawnPowerUp(x, y) {
    const types = [
        { type: 'BOMB', color: '#e74c3c', symbol: 'B' },
        { type: 'RANGE', color: '#3498db', symbol: 'R' },
        { type: 'SPEED', color: '#2ecc71', symbol: 'S' }
    ];
    
    const powerUp = {
        ...types[Math.floor(Math.random() * types.length)],
        x: x,
        y: y
    };
    
    gameState.powerUps.push(powerUp);
    socket.emit('powerUpSpawned', powerUp);
}

function collectPowerUp(powerUp) {
    const index = gameState.powerUps.findIndex(p => 
        p.x === powerUp.x && p.y === powerUp.y
    );
    
    if (index === -1) return;
    
    gameState.powerUps.splice(index, 1);
    gameState.score += 25;
    
    switch (powerUp.type) {
        case 'BOMB':
            gameState.playerStats.maxBombs++;
            break;
        case 'RANGE':
            gameState.playerStats.explosionRange++;
            break;
        case 'SPEED':
            gameState.playerStats.speedMultiplier = 1.5;
            setTimeout(() => {
                gameState.playerStats.speedMultiplier = 1;
            }, 10000);
            break;
    }
    
    updateStats();
}

// Collision detection
function checkCollision(x, y) {
    const gridX = Math.floor(x / GRID_SIZE);
    const gridY = Math.floor(y / GRID_SIZE);
    const radius = GRID_SIZE / 3;
    
    // Check wall collisions
    for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
            const checkX = gridX + dx;
            const checkY = gridY + dy;
            
            if (checkX < 0 || checkX >= COLS || checkY < 0 || checkY >= ROWS) {
                continue;
            }
            
            if (gameState.walls.has(`${checkX},${checkY}`) ||
                gameState.indestructibleWalls.has(`${checkX},${checkY}`)) {
                const wallX = checkX * GRID_SIZE;
                const wallY = checkY * GRID_SIZE;
                
                if (x + radius > wallX && x - radius < wallX + GRID_SIZE &&
                    y + radius > wallY && y - radius < wallY + GRID_SIZE) {
                    return true;
                }
            }
        }
    }
    
    // Check power-up collection
    const playerGridX = Math.floor(x / GRID_SIZE);
    const playerGridY = Math.floor(y / GRID_SIZE);
    
    for (const powerUp of gameState.powerUps) {
        if (powerUp.x === playerGridX && powerUp.y === playerGridY) {
            collectPowerUp(powerUp);
        }
    }
    
    return false;
}

function isPlayerInExplosion(player, explosionCells) {
    const playerGridX = Math.floor(player.x / GRID_SIZE);
    const playerGridY = Math.floor(player.y / GRID_SIZE);
    
    return explosionCells.some(cell => 
        cell.x === playerGridX && cell.y === playerGridY
    );
}

// UI updates
function updateUI() {
    // Update timer
    const minutes = Math.floor(gameState.elapsedTime / 60);
    const seconds = gameState.elapsedTime % 60;
    document.getElementById('timer').textContent = 
        `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    // Update score
    document.getElementById('score').textContent = gameState.score;
}

function updateStats() {
    document.getElementById('bomb-count').textContent = gameState.playerStats.maxBombs;
    document.getElementById('range-count').textContent = gameState.playerStats.explosionRange;
    document.getElementById('speed-count').textContent = 
        gameState.playerStats.speedMultiplier.toFixed(1);
}

// Game state management
function togglePause() {
    gameState.isPaused = !gameState.isPaused;
    screens.pause.style.display = gameState.isPaused ? 'flex' : 'none';
    
    if (!gameState.isPaused) {
        gameState.lastTimestamp = Date.now();
        requestAnimationFrame(gameLoop);
    }
}

function handlePlayerDeath() {
    gameState.isRunning = false;
    socket.emit('playerDied');
    showGameOver(false);
}

function showGameOver(isWinner) {
    const result = document.getElementById('game-result');
    result.textContent = isWinner ? 'You Won!' : 'Game Over';
    result.className = isWinner ? 'winner' : 'loser';
    
    document.getElementById('final-score').textContent = gameState.score;
    document.getElementById('final-time').textContent = document.getElementById('timer').textContent;
    
    showScreen('gameOver');
}

function playAgain() {
    socket.emit('playAgain');
}

function quitGame() {
    gameState.isRunning = false;
    socket.emit('quitGame');
    showScreen('start');
}

// Socket event handlers
socket.on('loginSuccess', (data) => {
    document.getElementById('player-username').textContent = data.username;
    showScreen('lobby');
});

socket.on('loginError', (error) => {
    document.getElementById('login-error').textContent = error;
});

socket.on('updateOnlineCount', (count) => {
    document.getElementById('online-count').textContent = count;
});

socket.on('waitingForMatch', () => {
    document.getElementById('lobby-status').textContent = 'Searching for opponent...';
});

socket.on('gameStart', (data) => {
    showScreen('game');
    initGame(data);
});

socket.on('playerMoved', (data) => {
    if (gameState.opponent && data.playerId === gameState.opponent.id) {
        gameState.opponent.x = data.x;
        gameState.opponent.y = data.y;
    }
});

socket.on('bombPlaced', (bomb) => {
    if (bomb.playerId !== socket.id) {
        gameState.bombs.set(bomb.id, bomb);
    }
});

socket.on('explosion', (data) => {
    const bomb = gameState.bombs.get(data.bombId);
    if (bomb) {
        detonateBomb(data.bombId);
    }
});

socket.on('powerUpSpawned', (powerUp) => {
    gameState.powerUps.push(powerUp);
});

socket.on('playerWon', () => {
    gameState.isRunning = false;
    showGameOver(true);
});

socket.on('playerLeft', (playerId) => {
    if (gameState.opponent && gameState.opponent.id === playerId) {
        showGameOver(true);
    }
});

socket.on('returnToLobby', () => {
    showScreen('start');
});

// Keyboard input
window.addEventListener('keydown', (e) => {
    if (keys.hasOwnProperty(e.key)) {
        keys[e.key] = true;
        if (e.key === ' ' && gameState.isRunning && !gameState.isPaused) {
            placeBomb();
        }
    }
});

window.addEventListener('keyup', (e) => {
    if (keys.hasOwnProperty(e.key)) {
        keys[e.key] = false;
    }
});

// Mobile controls
if ('ontouchstart' in window) {
    document.getElementById('mobile-controls').style.display = 'flex';
    
    const touchButtons = {
        'up-btn': { key: 'ArrowUp' },
        'down-btn': { key: 'ArrowDown' },
        'left-btn': { key: 'ArrowLeft' },
        'right-btn': { key: 'ArrowRight' },
        'bomb-btn': { key: ' ' }
    };
    
    for (const [id, data] of Object.entries(touchButtons)) {
        const button = document.getElementById(id);
        button.addEventListener('touchstart', (e) => {
            e.preventDefault();
            keys[data.key] = true;
            if (data.key === ' ') placeBomb();
        });
        button.addEventListener('touchend', (e) => {
            e.preventDefault();
            keys[data.key] = false;
        });
    }
}

// Initialize
loadSettings();
showScreen('start'); 